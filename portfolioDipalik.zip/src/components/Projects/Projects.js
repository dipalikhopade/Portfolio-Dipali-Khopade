import React, { useState } from "react";
import { Container, Row, Col, Modal, Button } from "react-bootstrap";
import Particle from "../Particle";
import ProjectCard from "./ProjectCards";
import WorkExperienceCard from "./WorkExperienceCard";

// Import project images
import chatify from "../../Assets/Projects/chatify.png";
import intellilogo from "../../Assets/Projects/webtitle.png";
import sarvmLogo from "../../Assets/Projects/sarvmpage.png";

function Projects() {
  const [selectedProject, setSelectedProject] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const projectData = [
    {
      imgPath: chatify,
      isBlog: false,
      title: "AMAZON Clone web page",
      description:
        "It is clone of Amazon shopping website made using React.js where user can select their product in basket and from basket go to payment also Login and authentication done by firebase",
      ghLink: "https://github.com/#/E-comAmazone",
      demoLink: "/",
    },
    {
      imgPath: chatify,
      isBlog: false,
      title: "Netflix Clone web page",
      description:
        "It is clone of Netflix web application made using react.js and TMDB API , user can watch movies trailer in a popup it its available on youtube",
      ghLink: "https://github.com/#/netflix-clone",
      demoLink: "/",
    },
    {
      imgPath: chatify,
      isBlog: false,
      title: "Quize web(MERN)",
      description:
        "It is a web page  in which user can login and select any category and take a short test and see result (MERN Stack)",
      ghLink: "https://github.com/#/MERN_Quiz",
      demoLink: "/",
    },
    {
      imgPath: chatify,
      isBlog: false,
      title: "Slack Chat web",
      description:
        "It is Real time chat application made using react where user can interact with each other personally or in a group For data storing",
      ghLink: "https://github.com/#",
      demoLink: "/",
    },
  ];

  const workExperienceData = [
    {
      imgPath: intellilogo,
      companyName: "IntelliEdtech",
      position: "Full Stack Developer",
      description:
        "I pioneered the transformation of education technology by concurrently managing frontend and backend development. Utilizing React Native for the frontend, I designed an intuitive interface with a dynamic content panel. On the backend, a robust Node.js server, MongoDB database, and a microservices architecture orchestrated by a load balancer ensured optimal scalability. The Teacher App introduced innovative features, fostering real-time connectivity, batch creation, and even e-commerce capabilities for selling educational resources.",
      duration: "August 2023 - Present",
    },
    {
      imgPath: sarvmLogo,
      companyName: "Sarvm.ai",
      position: "Software Engineer",
      description:
        "I played a key role in developing web applications and cross-platform apps for household, retailer, and logistic management using Ionic, Angular, and Node.js. My contributions encompassed crucial features such as user management, efficient delivery tracking, seamless retailer-to-logistic app integration, and dynamic delivery charge configuration.",
      duration: "January 2022 - July 2023",
    },
  ];

  const handleShowModal = (project) => {
    setSelectedProject(project);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedProject(null);
  };

  return (
    <Container fluid className="project-section">
      <Particle />
      <Container>
        {/* Work Experience Section */}
        <h1 className="project-heading">
          Work <strong className="purple">Experience</strong>
        </h1>
        <p style={{ color: "white" }}>
          My Recent <strong className="purple">Works </strong>
        </p>
        <Row style={{ justifyContent: "center", paddingBottom: "10px" }}>
          {workExperienceData.map((experience, index) => (
            <Col key={index} md={6} className="project-card">
              <WorkExperienceCard {...experience} />
            </Col>
          ))}
        </Row>

        <h1 style={{ color: "white" }}>
          Here are a few projects I've worked on recently.
        </h1>
        <Row style={{ justifyContent: "center", paddingBottom: "10px" }}>
          {projectData.map((project, index) => (
            <Col key={index} md={4} className="project-card">
              <div onClick={() => handleShowModal(project)}>
                <ProjectCard {...project} />
              </div>
            </Col>
          ))}
        </Row>

        {/* Modal for displaying project details */}
        {selectedProject && (
          <Modal show={showModal} onHide={handleCloseModal} centered>
            <Modal.Header closeButton>
              <Modal.Title>{selectedProject.title}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <img
                src={selectedProject.imgPath}
                alt={selectedProject.title}
                style={{ width: "100%", height: "auto" }}
              />
              <p>{selectedProject.description}</p>
              <Button href={selectedProject.ghLink} target="_blank">
                GitHub Repo
              </Button>{" "}
              <Button href={selectedProject.demoLink} target="_blank">
                Live Demo
              </Button>
            </Modal.Body>
          </Modal>
        )}
      </Container>
    </Container>
  );
}

export default Projects;
